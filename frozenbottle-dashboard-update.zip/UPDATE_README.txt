FROZEN BOTTLE SALES DASHBOARD - FULL UPDATE

Copy these folders into the GitHub repo (gsheet-automation), replacing the files with the same names:
  scripts/                      Python sync and build scripts
  site/                         Dashboard pages and scripts (deployed to Cloudflare Pages)
  functions/                    Sign-in and per-login data function (data/[[path]].js)
  .github/workflows/            update-dashboard.yml (sales) and kpt.yml (KPT and O2D)

Do not delete other files in the repo (historical_data/, data/ and other folders stay as they are).

Then:
1. Commit the changes on the main branch.
2. Actions -> Update sales dashboard -> Run workflow -> mode: live.
3. Check the build log for "done:" and the Safety check step passing.
