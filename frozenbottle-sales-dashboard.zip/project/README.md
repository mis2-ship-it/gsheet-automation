# Frozen Bottle sales dashboard

A phone-first dashboard for sales and ratings across Frozen Bottle, Madno, Boba Bar and Lubov.

- `site/` is the web app. `site/index.html` reads the files in `site/data/`.
- `scripts/build_site.py` builds `site/data/` from the sales history, the new days, today's live sales, and the ratings.
- `scripts/sync_sales.py` pulls sales from Rista (same calls and mapping as `rista_live.py`).
- `scripts/sync_ratings.py` reads the Swiggy, Zomato and Google rating sheets.
- `.github/workflows/update-dashboard.yml` runs the sync and the build, then deploys `site/`.

## Setup (one time)

1. Put this folder into the `gsheet-automation` repository. Keep `data/historical_sales.csv.gz` where it already is.
2. Add these repository secrets (the first three already exist for `rista_live.py`):
   `API_KEY`, `SECRET_KEY`, `GOOGLE_CREDENTIALS`, `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`.
3. Create a Cloudflare Pages project named `frozenbottle-sales`. Add `app.frozenbottle.com` as its custom domain.
4. Turn on Cloudflare Access for `app.frozenbottle.com` and allow only company email addresses. Without this, anyone with the link can see the sales.
5. Run the workflow once by hand with `mode = nightly` to fill September onwards.

## Data rules

- Store type and region come from the `Help Sheet` tab, as in `rista_live.py`. Stores missing there show as `Unmapped` and count under All only.
- Online means Swiggy, Zomato and Others. Offline means In Store.
- Ratings: average rating is weighted by Rated Orders. Coverage is rated orders divided by orders.
- Rating sheet dates are month-first (10-11-2026 is 11 October 2026).

## Preview on your computer

    cd site && python3 -m http.server 8000

Then open http://localhost:8000. Note that the Live and Ratings screens stay empty until the sync has run.
